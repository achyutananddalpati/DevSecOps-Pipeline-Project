| Port | Service | Version | Protocol |
|------|---------|---------|----------|
| 443 | ssl/http | ssl/http nginx 1.24.0 (Ubuntu) | tcp |
