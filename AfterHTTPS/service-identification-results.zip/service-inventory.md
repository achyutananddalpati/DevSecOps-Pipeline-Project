# Complete Service Inventory Report
Target: 13.205.25.48
Scan Date: Fri Mar 20 18:57:49 UTC 2026
Scan Type: Deep Service Identification

## Executive Summary

- **Total Open Ports:** 1
- **Scan Method:** Version detection without OS scan

## Detailed Service Inventory

| Port | Service | Version | Protocol | Details |
|------|---------|---------|----------|---------|
| 443 | ssl/http | ssl/http nginx 1.24.0 (Ubuntu) | tcp | Full details in raw scan |

## Security Notes

See 'outdated-services.md' for version-specific security recommendations.
