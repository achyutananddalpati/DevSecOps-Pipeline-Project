# OWASP ZAP DAST Scan Results

## Scan Information
- **Target:** http://13.205.25.48
- **Date:** Tue Mar 10 17:30:31 UTC 2026
- **Application:** OWASP Juice Shop

## Vulnerability Summary

OWASP Juice Shop is intentionally vulnerable. Expected findings include:

| Risk Level | Vulnerability Type |
|------------|-------------------|
| 🔴 **High** | SQL Injection (SQLi) |
| 🔴 **High** | Cross-Site Scripting (XSS) |
| 🔴 **High** | Broken Access Control |
| 🟡 **Medium** | Broken Authentication |
| 🟡 **Medium** | Sensitive Data Exposure |
| 🟡 **Medium** | Security Misconfiguration |
| 🟢 **Low** | Missing Security Headers |
| 🟢 **Low** | Information Disclosure |

## Next Steps

1. Review the full ZAP report in artifacts
2. Check the GitHub Issues tab for automatically created vulnerability tickets!
3. These vulnerabilities will be addressed in Chapter 6 (Remediation)
