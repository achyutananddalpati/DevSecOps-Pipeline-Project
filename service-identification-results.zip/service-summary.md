| Port | Service | Version | Protocol |
|------|---------|---------|----------|
| 22 | ssh |  ssh     OpenSSH 9.6p1 Ubuntu 3ubuntu13.14 (Ubuntu Linux; protocol 2.0) | tcp |
| 80 | http |  http | tcp |
| 443 | https |  | tcp |
