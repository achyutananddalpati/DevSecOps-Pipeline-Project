# Complete Service Inventory Report
Target: 13.205.25.48
Scan Date: Sun Mar  8 09:22:15 UTC 2026
Scan Type: Deep Service Identification

## Executive Summary

- **Total Open Ports:** 3
- **Scan Method:** Version detection without OS scan

## Detailed Service Inventory

| Port | Service | Version | Protocol | Details |
|------|---------|---------|----------|---------|
| 22 | ssh |   ssh     OpenSSH 9.6p1 Ubuntu 3ubuntu13.14 (Ubunt | tcp | Full details in raw scan |
| 80 | http |   http | tcp | Full details in raw scan |
| 443 | https |  | tcp | Full details in raw scan |

## Security Notes

See 'outdated-services.md' for version-specific security recommendations.
